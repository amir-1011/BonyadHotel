<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'پنل مدیریت') | سامانه رزرو</title>
    <link rel="stylesheet" href="{{ asset('vendor/bootstrap/bootstrap.rtl.min.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/bootstrap-icons/bootstrap-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('vendor/vazirmatn/Vazirmatn-font-face.min.css') }}">
    <style>
        body { font-family: 'Vazirmatn', sans-serif; background: #f1f5f9; }
        :root { --sidebar-w: 260px; }
        #sidebar { width: var(--sidebar-w); min-height: 100vh; background: linear-gradient(180deg,#1e3a5f 0%,#0d2137 100%); position: fixed; top:0; right:0; z-index: 1040; transition: transform .3s; }
        #sidebar .brand { padding: 1.2rem 1rem; border-bottom: 1px solid rgba(255,255,255,.1); }
        #sidebar .nav-link { color: rgba(255,255,255,.75); padding: .6rem 1rem; border-radius: 8px; margin: 2px 8px; font-size: .9rem; }
        #sidebar .nav-link:hover, #sidebar .nav-link.active { background: rgba(255,255,255,.12); color:#fff; }
        #sidebar .nav-link i { width: 22px; text-align: center; }
        #sidebar .section-label { font-size: .7rem; color: rgba(255,255,255,.4); text-transform: uppercase; padding: .5rem 1rem; margin-top: .5rem; letter-spacing: .5px; }
        #main-content { margin-right: var(--sidebar-w); min-height: 100vh; }
        .topbar { background: #fff; border-bottom: 1px solid #e2e8f0; padding: .75rem 1.5rem; }
        .stat-card { border-radius: 14px; border: none; }
        .stat-icon { width: 52px; height: 52px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; }
        @media(max-width:991px){
            #sidebar { transform: translateX(100%); }
            #sidebar.show { transform: translateX(0); }
            #main-content { margin-right: 0; }
        }
        .table th { font-size: .82rem; color: #64748b; font-weight: 600; }
        .badge { font-size: .75rem; }
    </style>
    @stack('styles')
</head>
<body>

{{-- Sidebar --}}
<div id="sidebar">
    <div class="brand d-flex align-items-center gap-2">
        <div style="background:rgba(255,255,255,.15);border-radius:8px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;">
            <i class="bi bi-shield-fill text-white"></i>
        </div>
        <div>
            <div class="text-white fw-bold">پنل مدیریت</div>
            <div style="font-size:.7rem;color:rgba(255,255,255,.5)">سوپر ادمین</div>
        </div>
    </div>
    <nav class="mt-2 pb-4">
        <div class="section-label">داشبورد</div>
        <a href="{{ route('admin.dashboard') }}" class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
            <i class="bi bi-speedometer2 me-2"></i> داشبورد
        </a>

        <div class="section-label">مدیریت</div>
        <a href="{{ route('admin.users.index') }}" class="nav-link {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
            <i class="bi bi-people me-2"></i> کاربران
        </a>
        <a href="{{ route('admin.accommodations.index') }}" class="nav-link {{ request()->routeIs('admin.accommodations.*') ? 'active' : '' }}">
            <i class="bi bi-building me-2"></i> اقامتگاه‌ها
        </a>
        <a href="{{ route('admin.bookings.index') }}" class="nav-link {{ request()->routeIs('admin.bookings.*') ? 'active' : '' }}">
            <i class="bi bi-calendar-check me-2"></i> رزروها
        </a>
        <a href="{{ route('admin.reviews.index') }}" class="nav-link {{ request()->routeIs('admin.reviews.*') ? 'active' : '' }}">
            <i class="bi bi-star me-2"></i> نظرات
        </a>

        <div class="section-label">دسترسی سریع</div>
        <a href="{{ route('home') }}" class="nav-link" target="_blank">
            <i class="bi bi-house me-2"></i> سایت اصلی
        </a>
        <form action="{{ route('auth.logout') }}" method="POST" class="d-inline">
            @csrf
            <button type="submit" class="nav-link border-0 bg-transparent w-100 text-start">
                <i class="bi bi-box-arrow-left me-2"></i> خروج
            </button>
        </form>
    </nav>
</div>

{{-- Main --}}
<div id="main-content">
    <div class="topbar d-flex align-items-center justify-content-between">
        <button class="btn btn-sm btn-outline-secondary d-lg-none" onclick="document.getElementById('sidebar').classList.toggle('show')">
            <i class="bi bi-list fs-5"></i>
        </button>
        <div class="text-muted small">@yield('page-title', 'داشبورد')</div>
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-danger">سوپر ادمین</span>
            <span class="fw-semibold small">{{ Auth::user()->name ?? Auth::user()->mobile }}</span>
        </div>
    </div>

    <div class="p-3 p-lg-4">
        @if(session('status'))
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle-fill me-2"></i>{{ session('status') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if($errors->any())
            <div class="alert alert-danger alert-dismissible fade show">
                <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @yield('content')
    </div>
</div>

<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('vendor/bootstrap/bootstrap.bundle.min.js') }}"></script>
<!-- <script>
(function(){
    var fa=['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    var SK=['SCRIPT','STYLE','INPUT','TEXTAREA','SELECT'];
    function cv(root){var w=document.createTreeWalker(root||document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){return SK.indexOf(n.parentElement&&n.parentElement.tagName)!==-1?NodeFilter.FILTER_REJECT:/[0-9]/.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});var ns=[],n;while((n=w.nextNode()))ns.push(n);ns.forEach(function(n){n.nodeValue=n.nodeValue.replace(/[0-9]/g,function(d){return fa[d];});});}
    document.addEventListener('DOMContentLoaded',function(){cv();new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(a){if(a.nodeType===1)cv(a);else if(a.nodeType===3&&/[0-9]/.test(a.nodeValue)){var t=a.parentElement&&a.parentElement.tagName;if(SK.indexOf(t)===-1)a.nodeValue=a.nodeValue.replace(/[0-9]/g,function(d){return fa[d];});}});});}).observe(document.body,{childList:true,subtree:true});});
})();
</script> -->
@stack('scripts')
</body>
</html>
